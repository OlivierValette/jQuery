-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:8889
-- Généré le :  Mar 10 Janvier 2017 à 17:35
-- Version du serveur :  5.6.33
-- Version de PHP :  7.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dc_gmap`
--
CREATE DATABASE IF NOT EXISTS `dc_gmap` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `dc_gmap`;

-- --------------------------------------------------------

--
-- Structure de la table `spots`
--

DROP TABLE IF EXISTS `spots`;
CREATE TABLE `spots` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` float(10,6) DEFAULT NULL,
  `longitude` float(10,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `spots`
--

INSERT INTO `spots` (`id`, `title`, `content`, `image`, `latitude`, `longitude`) VALUES
(1, 'Le Sillon - Saint Malo', '<p>Un bon spot de surf pour tous près du centre de Saint-Malo, facilement accessible, trop, diront certains, car la plage est vite saturée. A surfer de préférence en automne, à marée montante.</p>\r\n<p>Niveau : débutants à confirmés. Pas de difficultés particulière.</p>\r\n<p>Accès au spot : Boulevard Hébert à Saint-Malo. Bus ligne 8, arrêt Digue.</p>', 'images/sillon.jpg', 48.655239, -2.009418),
(2, 'Perros-Guirec', '<p>Un bon shore-break assez accessible avec, parfois, de grosses conditions qui satisfont les confirmés et surprennent les débutants. Attention à bien jauger son niveau. Un spot à surfer à marée montante pendant de l’automne au printemps. Parking et douches à proximité.</p>\r\n<p>Niveau : Intermédiaire. Attention aux galets lors de la mise à l’eau...</p>\r\n<p>Accès au spot : Boulevard Joseph Le Bihan. correspondance bus Lannion - Perros-Guirec Tibus sur la ligne 15, arrêt Trestaou.</p>', 'images/perros.jpg', 48.817123, -3.456960),
(3, 'Les Blanc-Sablons - Le Conquet', '<p>Un beach-break exposé à la houle avec un fort vent Nord-Nord-Ouest qui n’est pas à la portée de tout le monde. Cette vague est à surfer à marée montante, de l’automne au printemps. Parking à proximité.</p>\r\n<p>Niveau : Intermédiaires à confirmés. Des rochers parfois cachés...</p>\r\n<p>Accès au spot : Pmage des Blanc-Sablons. 131TAD (transport à la demande) - Ploumoguer- Saint Renan- Brest, arrêt Ilien.</p>', 'images/conquet.jpg', 48.368641, -4.766203),
(4, 'Baie des Trépassés - Lescoff', '<p>Ce beach-break de repli est situé dans un coin sauvage de Bretagne et constitue l’un des sites préférés des surfeurs de la région. De grande vagues qui déroulent sans s’arrêter grâce à un vent Nord-Nord-Ouest puissant, des conditions idéales à marée basse de l’automne au printemps.</p>\r\n<p>Niveau : Intermédiaires à confirmés. Les courants peuvent vous déporter vers les falaises.</p>\r\n<p>Accès au spot : Route de la Baie D607 ; Bus 53B Viaoo Audierne - Quimper arrêt Laoual.</p>', 'images/trepasses.jpg', 48.047062, -4.706990),
(5, 'La Barre d’Etel', '<p>De par sa situation dans un estuaire, ce spot propose une vague très technique et parfois dangereuse du fait du fort courant qui l’anime. Un site à ne pas découvrir seul et sans entraînement, mais qui vaut la peine d’être testé une fois que l’on a atteint un bon niveau et que les conditions sont optimales : vent du Nord et marée montante.</p>\r\n<p>Niveau : Confirmé.</p>\r\n<p>Accès au spot : Le Magouero ; Bus ligne 16B TIM Lorient- Plouhinec, arrêt Place Kilkee Kerpotence.</p>', 'images/etel.jpg', 47.642746, -3.213410);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `spots`
--
ALTER TABLE `spots`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `spots`
--
ALTER TABLE `spots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
